import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navigation from './Components/Navigation';
import Home from './Components/Home';
import { BrowserRouter,Routes,Route} from 'react-router-dom'
import Test from './Components/Test';



function App() {
  return (
    <>
    <div>
    <BrowserRouter>
    <Routes>
      <Route path='Home' element={<Home />} />
      <Route path='Test' element={<Test />} />

    </Routes>
    </BrowserRouter>

<Navigation />
</div>
   </>
  );
}

export default App;
