import React from 'react'
export default function Home() {
  return (
    <div>
        <h1> this is data of home page</h1>
    </div>
  )
}
