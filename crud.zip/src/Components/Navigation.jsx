import React from 'react'
import {Navbar,Nav,Container} from 'react-bootstrap'
import {BrowserRouter,Route,Routes,Link}from 'react-router-dom'
import Home from './Home'

export default function Navigation(){
  return (

      <>
      
  <Navbar bg="dark" variant="dark">
    <Container>

    <Nav className="me-auto">
      
      <Nav.Link  to='Home'>Home</Nav.Link>
      {/* <Nav.Link to="Test">Features</Nav.Link>
      <Nav.Link href="#pricing">Pricing</Nav.Link> */}
    </Nav>
   
    </Container>
  </Navbar>
  
</>
  )
}
